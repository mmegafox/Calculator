﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CalculatorLibrary;

namespace Test
{
    public partial class GrishinMaxim402 : Form
    {
        private string fl;

        public GrishinMaxim402()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Button btn = (Button)sender;
                switch(btn.Name)
                {
                    case "button1":
                        textBox1.Text = textBox1.Text + "1";
                        break;
                    case "button2":
                        textBox1.Text = textBox1.Text + "2";
                        break;
                    case "button3":
                        textBox1.Text = textBox1.Text + "3";
                        break;
                    case "button4":
                        textBox1.Text = textBox1.Text + "+";
                        break;
                    case "button5":
                        textBox1.Text = textBox1.Text + "4";
                        break;
                    case "button6":
                        textBox1.Text = textBox1.Text + "5";
                        break;
                    case "button7":
                        textBox1.Text = textBox1.Text + "6";
                        break;
                    case "button8":
                        textBox1.Text = textBox1.Text + "-";
                        break;
                    case "button9":
                        textBox1.Text = textBox1.Text + "7";
                        break;
                    case "button10":
                        textBox1.Text = textBox1.Text + "8";
                        break;
                    case "button11":
                        textBox1.Text = textBox1.Text + "9";
                        break;
                    case "button12":
                        textBox1.Text = textBox1.Text + "*";
                        break;
                    case "button13":
                        textBox1.Text = textBox1.Text + "(";
                        break;
                    case "button14":
                        textBox1.Text = textBox1.Text + "0";
                        break;
                    case "button15":
                        textBox1.Text = textBox1.Text + ")";
                        break;
                    case "button16":
                        textBox1.Text = textBox1.Text + "/";
                        break;
                    case "button17":
                        textBox1.Text = textBox1.Text + CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
                        break;
                    case "button18":
                        textBox1.Text = string.Empty;
                        break;
                    case "button19":
                        Reshenie();
                        break;
                    case "button20":
                        Reshenie();
                        double s = Math.Pow(double.Parse(textBox1.Text), 2);
                        textBox1.Text = string.Empty;
                        textBox1.Text = s.ToString();
                        break;
                    case "button21":
                        Reshenie();
                        double f = double.Parse(textBox1.Text);
                        long fl = 1;
                        for (int i = 1; i <= f; i++)
                        {
                            fl *= i;
                        }
                        textBox1.Text = string.Empty;
                        textBox1.Text = fl.ToString();
                        break;
                    case "button22":
                        Reshenie();
                        double m = Math.Abs(double.Parse(textBox1.Text));
                        textBox1.Text = string.Empty;
                        textBox1.Text = m.ToString();
                        break;
                    case "button23":
                        Reshenie();
                        double k = Math.Sqrt(double.Parse(textBox1.Text));
                        textBox1.Text = string.Empty;
                        textBox1.Text = k.ToString();
                        break;
                    case "button24":
                        Reshenie();
                        double st = Math.Pow(10, double.Parse(textBox1.Text));
                        textBox1.Text = string.Empty;
                        textBox1.Text = st.ToString();
                        break;
                    case "button25":
                        Reshenie();
                        double x = 1/double.Parse(textBox1.Text);
                        textBox1.Text = string.Empty;
                        textBox1.Text = x.ToString();
                        break;
                    case "button26":
                        Reshenie();
                        double log = Math.Log10(double.Parse(textBox1.Text));
                        textBox1.Text = string.Empty;
                        textBox1.Text = log.ToString();
                        break;
                    case "button27":
                        Reshenie();
                        double In = Math.Log(double.Parse(textBox1.Text));
                        textBox1.Text = string.Empty;
                        textBox1.Text = In.ToString();
                        break;
                    case "button28":
                        Reshenie();
                        double P = Math.PI;
                        textBox1.Text = P.ToString();
                        break;
                }
            }
            catch
            {
                MessageBox.Show("Кажется что-то пошло не так.");
            }
        }
        private void Reshenie()
        {
            toolStripStatusLabel.Text = string.Empty;
            Context context = new Context(textBox1.Text);
            decimal value = context.CalculateRealValue();
            textBox1.Text = value.ToString();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
